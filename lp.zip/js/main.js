// =======================
// Хэдер липкий
// =======================

$(window).scroll(function(){
	if($(this).scrollTop()>1){
		$('.js-scroll').addClass('header__scroll');

	}
	else if ($(this).scrollTop()<1){
		$('.js-scroll').removeClass('header__scroll');
	
	}
});

// =======================
// Хэдер бургер открытие
// =======================
$('.js-burgerOpen').click(function() {
	$('.popup').fadeIn();
	return false;
});

$('.js-burgerClose').click(function() {
	$('.popup').fadeOut();
	return false;
});

// =======================
// Карточка получить консультацию
// =======================
$('.js-formOpen').click(function(event) {
	event.preventDefault();
	$('.popup-card--form').fadeIn().css('display','flex');
	return false;
});

$('.js-popupcardClose').click(function() {
	$('.popup-card--form').fadeOut();
	return false;
});

$(document).mouseup(function (e) {
	var popup = $('.popup-card__body');
	if (e.target!=popup[0]&&popup.has(e.target).length === 0){
		$('.popup-card--form').fadeOut();
	}
});

// =======================
// Карточка товара открытие
// =======================
$('.js-cardOpen').click(function() {
	$('.popup-card--single').fadeIn().css('display','flex');
	return false;
});

$('.js-popupcardClose').click(function() {
	$('.popup-card--single').fadeOut();
	return false;
});

$(document).mouseup(function (e) {
	var popup = $('.popup-card__body');
	if (e.target!=popup[0]&&popup.has(e.target).length === 0){
		$('.popup-card--single').fadeOut();
	}
});

// =======================
// Слайдер столярные изделия
// =======================
const swiper = new Swiper(".jobSwiper", {
	slidesPerView: 3,
	slidesPerGroup: 3,
	spaceBetween: 24,
	pagination: {
		el: ".swiper-pagination",
		type: "fraction",
	},
	navigation: {
		nextEl: ".js-jobNext",
		prevEl: ".js-jobPrev",
	},
	renderFraction: function (currentClass, totalClass) {
		return '<span class="' + currentClass + '"></span>' +
			'' +
			'<span class="' + totalClass + '"></span>';
	},
});

// =======================
// Материалы hover
// =======================
	$('.materials__wood').hover(
		function () {
			$(this) .addClass('materials__wood--hover');  // Добавляем класс
		},
		function () {
			$(this) .removeClass('materials__wood--hover');  // Убираем класс
		}
	);


// =======================
// Попап меню hover
// =======================

	$('.popup__items').hover(
		function () {
			$(this).siblings().addClass('popup__items--hover');  // Добавляем класс
		},
		function () {
			$(this).siblings().removeClass('popup__items--hover');  // Убираем класс
		}
	);


// =======================
// Сертификаты табы
// =======================

$('.js-tab-trigger').click(function() {
	var id = $(this).attr('data-tab'),
		content = $('.js-tab-content[data-tab="'+ id +'"]');
	
	$('.js-tab-trigger.active').removeClass('active');
	$(this).addClass('active');
	
	$('.js-tab-content.active').removeClass('active');
	content.addClass('active');
});

// =======================
// Горизонтальный скролл
// =======================
TweenLite.defaultEase = Linear.easeNone;
var titles = document.querySelectorAll(".sectionTitle");
var controller = new ScrollMagic.Controller();
var tl = new TimelineMax();

// create timeline
// this could also be created in a loop
tl.to("#js-slideContainer", 1, {xPercent: -100}, "label1");
tl.from(titles[1], 0.5, {opacity:0}, "label1+=0.5");
tl.to("#js-slideContainer", 1, {xPercent: -200}, "label2");
tl.from(titles[2], 0.5, {opacity:0}, "label2+=0.5");
tl.to("#js-slideContainer", 1, {xPercent: -300}, "label3");
tl.from(titles[3], 0.5, {opacity:0}, "label3+=0.5");
tl.to("#js-slideContainer", 1, {xPercent: -400}, "label4");
tl.from(titles[4], 0.5, {opacity:0}, "label4+=0.5");


new ScrollMagic.Scene({
	triggerElement: "#js-wrapper",
	triggerHook: "onLeave",
	duration: "300%"
})
	.setPin("#js-wrapper")
	.setTween(tl)
	// .addIndicators({
	// 	colorTrigger: "white",
	// 	colorStart: "white",
	// 	colorEnd: "white",
	// })
	.addTo(controller);

// =======================
// Вертикальный скролл
// =======================
//
var controller = new ScrollMagic.Controller();
var tl = new TimelineMax();
tl.fromTo(
	"section.panel.turqoise",
	1,
	{ yPercent: 100 },
	{ yPercent: 0, ease: Linear.easeNone },
	"+=1"
);
tl.fromTo(
	"section.panel.bordeaux",
	1,
	{ yPercent: 100 },
	{ yPercent: 0, ease: Linear.easeNone },
	"+=1"
);

new ScrollMagic.Scene({
	triggerElement: "#pinMaster",
	triggerHook: "onLeave",
	duration: "100%"
})
	.setPin("#pinMaster")
	.setTween(tl)
	.addIndicators({
		colorTrigger: "white",
		colorStart: "white",
		colorEnd: "white",
		indent: 40
	})
	.addTo(controller);